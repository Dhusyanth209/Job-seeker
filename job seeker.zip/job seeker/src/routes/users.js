const express = require('express');
const router = express.Router();
const { db } = require('../../server');

// Apply for job
router.post('/apply/:job_id', (req, res) => {
  const { jobseeker_id, cover_letter } = req.body;

  if (!jobseeker_id) {
    return res.status(400).json({ error: 'Job seeker ID required' });
  }

  db.run(
    'INSERT INTO job_applications (job_id, jobseeker_id, cover_letter) VALUES (?, ?, ?)',
    [req.params.job_id, jobseeker_id, cover_letter],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to apply' });
      }
      res.status(201).json({ message: 'Application submitted successfully', id: this.lastID });
    }
  );
});

// Get applications for job seeker
router.get('/seeker/:user_id/applications', (req, res) => {
  db.all(
    `SELECT ja.*, jl.title, jl.company_name FROM job_applications ja
     JOIN job_listings jl ON ja.job_id = jl.id
     WHERE ja.jobseeker_id = ?
     ORDER BY ja.application_date DESC`,
    [req.params.user_id],
    (err, applications) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(applications);
    }
  );
});

// Get applications for employer
router.get('/employer/:user_id/applications', (req, res) => {
  db.all(
    `SELECT ja.*, jl.title, u.full_name, u.email FROM job_applications ja
     JOIN job_listings jl ON ja.job_id = jl.id
     JOIN users u ON ja.jobseeker_id = u.id
     WHERE jl.employer_id = ?
     ORDER BY ja.application_date DESC`,
    [req.params.user_id],
    (err, applications) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(applications);
    }
  );
});

// Update application status
router.put('/:app_id/status', (req, res) => {
  const { status } = req.body;

  db.run(
    'UPDATE job_applications SET status = ? WHERE id = ?',
    [status, req.params.app_id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to update status' });
      }
      res.json({ message: 'Application status updated' });
    }
  );
});

// Get user profile
router.get('/profile/:user_id', (req, res) => {
  db.get('SELECT * FROM users WHERE id = ?', [req.params.user_id], (err, user) => {
    if (err || !user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.user_type === 'jobseeker') {
      db.get('SELECT * FROM jobseeker_profiles WHERE user_id = ?', [user.id], (err, profile) => {
        res.json({ ...user, profile });
      });
    } else {
      db.get('SELECT * FROM employer_profiles WHERE user_id = ?', [user.id], (err, profile) => {
        res.json({ ...user, profile });
      });
    }
  });
});

module.exports = router;
