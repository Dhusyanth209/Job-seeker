const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
// Serve global styles
app.use('/styles', express.static(path.join(__dirname, 'styles')));

// Serve HTML files
app.set('view engine', 'html');
app.set('views', path.join(__dirname, 'views'));
app.engine('html', (filepath, options, callback) => {
  require('fs').readFile(filepath, (err, content) => {
    if (err) return callback(err);
    return callback(null, content.toString());
  });
});

// Database initialization
const db = new sqlite3.Database('./jobportal.db', (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
    initializeDatabase();
  }
});

// Initialize database schema
function initializeDatabase() {
  db.serialize(() => {
    // Users table
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        full_name TEXT NOT NULL,
        user_type TEXT NOT NULL,
        profile_pic TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Job Seeker Profiles
    db.run(`
      CREATE TABLE IF NOT EXISTS jobseeker_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        bio TEXT,
        phone TEXT,
        location TEXT,
        resume_url TEXT,
        skills TEXT,
        experience TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
      )
    `);

    // Employer Profiles
    db.run(`
      CREATE TABLE IF NOT EXISTS employer_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        company_name TEXT NOT NULL,
        company_size TEXT,
        industry TEXT,
        website TEXT,
        phone TEXT,
        location TEXT,
        description TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
      )
    `);

    // Job Listings
    db.run(`
      CREATE TABLE IF NOT EXISTS job_listings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employer_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        job_type TEXT,
        location TEXT,
        salary_min REAL,
        salary_max REAL,
        qualifications TEXT,
        responsibilities TEXT,
        posted_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        deadline DATETIME,
        status TEXT DEFAULT 'active',
        FOREIGN KEY(employer_id) REFERENCES users(id)
      )
    `);

    // Job Applications
    db.run(`
      CREATE TABLE IF NOT EXISTS job_applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER NOT NULL,
        jobseeker_id INTEGER NOT NULL,
        application_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'pending',
        cover_letter TEXT,
        FOREIGN KEY(job_id) REFERENCES job_listings(id),
        FOREIGN KEY(jobseeker_id) REFERENCES users(id)
      )
    `);

    console.log('Database schema initialized');
  });
}

// Routes
app.get('/', (req, res) => {
  res.render('index.html');
});

app.get('/login', (req, res) => {
  res.render('login.html');
});

app.get('/register', (req, res) => {
  res.render('register.html');
});

app.get('/dashboard', (req, res) => {
  res.render('dashboard.html');
});

app.get('/jobs', (req, res) => {
  res.render('jobs.html');
});

// API Routes - Auth
const authRoutes = require('./src/routes/auth');
app.use('/api/auth', authRoutes);

// API Routes - Jobs
const jobRoutes = require('./src/routes/jobs');
app.use('/api/jobs', jobRoutes);

// API Routes - Users
const userRoutes = require('./src/routes/users');
app.use('/api/users', userRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

module.exports = { db };
