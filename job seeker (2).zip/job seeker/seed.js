const { db } = require('./src/config/db');

const jobs = [
    {
        employer_id: 1,
        title: "Senior Frontend Developer",
        description: "We are looking for an experienced Frontend Developer to join our team. You will be responsible for building high-quality, responsive web applications using React and Tailwind CSS.",
        job_type: "Full-time",
        location: "Remote",
        salary_min: 120000,
        salary_max: 150000,
        qualifications: "5+ years of experience with React, TypeScript, and modern CSS.",
        responsibilities: "Develop new features, optimize performance, collaborate with designers.",
        deadline: "2024-12-31"
    },
    {
        employer_id: 1,
        title: "Backend Engineer (Node.js)",
        description: "Join our backend team to build scalable APIs and microservices. Experience with Node.js, Express, and PostgreSQL is required.",
        job_type: "Full-time",
        location: "New York, NY",
        salary_min: 130000,
        salary_max: 160000,
        qualifications: "Strong Node.js skills, database design, API security.",
        responsibilities: "Design and implement API endpoints, manage database schema.",
        deadline: "2024-11-30"
    },
    {
        employer_id: 1,
        title: "UI/UX Designer",
        description: "Creative designer needed to shape the user experience of our products. You should have a strong portfolio demonstrating UI and UX skills.",
        job_type: "Part-time",
        location: "London, UK",
        salary_min: 60000,
        salary_max: 80000,
        qualifications: "Proficiency in Figma, Adobe XD. Understanding of user-centered design.",
        responsibilities: "Create wireframes, prototypes, and high-fidelity mockups.",
        deadline: "2024-10-15"
    },
    {
        employer_id: 1,
        title: "DevOps Specialist",
        description: "We need a DevOps specialist to manage our cloud infrastructure and CI/CD pipelines. AWS experience is a must.",
        job_type: "Contract",
        location: "Remote",
        salary_min: 100000,
        salary_max: 140000,
        qualifications: "AWS certification, Docker, Kubernetes, Jenkins.",
        responsibilities: "Maintain cloud infrastructure, automate deployment processes.",
        deadline: "2024-12-01"
    },
    {
        employer_id: 1,
        title: "Product Manager",
        description: "Lead the product vision and strategy. You will work closely with engineering, design, and marketing teams.",
        job_type: "Full-time",
        location: "San Francisco, CA",
        salary_min: 140000,
        salary_max: 180000,
        qualifications: "Experience in product management, agile methodologies.",
        responsibilities: "Define product roadmap, prioritize features, analyze market trends.",
        deadline: "2025-01-20"
    }
];

// Seed Function
const seed = () => {
    // Ensure at least one user exists for foreign key
    db.run(`INSERT OR IGNORE INTO users (id, email, password, full_name, user_type) VALUES (1, 'demo@example.com', 'password', 'Demo Employer', 'employer')`, (err) => {
        if (err) console.error("Error creating demo user:", err);
        else console.log("Demo user ensured.");

        // Insert jobs
        const stmt = db.prepare(`INSERT INTO job_listings (employer_id, title, description, job_type, location, salary_min, salary_max, qualifications, responsibilities, deadline) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

        jobs.forEach(job => {
            stmt.run([job.employer_id, job.title, job.description, job.job_type, job.location, job.salary_min, job.salary_max, job.qualifications, job.responsibilities, job.deadline], (err) => {
                if (err) console.error("Error inserting job:", err);
                else console.log(`Inserted job: ${job.title}`);
            });
        });

        stmt.finalize(() => {
            console.log("Seeding complete.");
            // We don't close DB here because this script runs in context of server if we require it, 
            // but easier to run as standalone.
        });
    });
};

seed();
