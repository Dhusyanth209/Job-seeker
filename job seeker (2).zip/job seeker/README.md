# Job Listing Portal - Base Implementation

A dynamic web application that connects job seekers with potential employers. This is the foundational version with core features ready for expansion.

## Features

### Current (Base Implementation)
- **User Authentication**: Registration and login for job seekers and employers
- **Profile Management**: Basic profile setup for both user types
- **Job Listings**: Browse available jobs with search and filtering
- **Dashboard**: Personalized dashboard for managing profile and applications
- **Basic API**: RESTful API endpoints for core functionality

### Database Schema
- Users (authentication, basic info)
- Job Seeker Profiles (bio, skills, experience)
- Employer Profiles (company info, details)
- Job Listings (full job descriptions with details)
- Job Applications (track applications)

## Project Structure

```
job-seeker/
├── server.js                 # Main Express server
├── package.json             # Project dependencies
├── .env                     # Environment variables
├── jobportal.db            # SQLite database
├── public/                 # Static files
├── src/
│   ├── routes/
│   │   ├── auth.js        # Authentication routes
│   │   ├── jobs.js        # Job listing routes
│   │   └── users.js       # User profile routes
│   ├── models/            # Database models (for future)
│   └── controllers/       # Business logic (for future)
├── views/                 # HTML pages
│   ├── index.html         # Home page
│   ├── register.html      # Registration page
│   ├── login.html         # Login page
│   ├── jobs.html          # Browse jobs page
│   └── dashboard.html     # User dashboard
└── styles/
    └── style.css          # CSS styling
```

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm (comes with Node.js)

### Steps

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Run the Server**
   ```bash
   npm start
   ```
   or for development with auto-reload:
   ```bash
   npm run dev
   ```

3. **Access the Application**
   Open your browser and go to `http://localhost:5000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Jobs
- `GET /api/jobs` - Get all jobs (supports filters)
- `GET /api/jobs/:id` - Get single job
- `POST /api/jobs` - Create job (employer)
- `PUT /api/jobs/:id` - Update job
- `DELETE /api/jobs/:id` - Delete job

### Users
- `GET /api/users/profile/:user_id` - Get user profile
- `POST /api/users/apply/:job_id` - Apply for job
- `GET /api/users/seeker/:user_id/applications` - Get job seeker applications
- `GET /api/users/employer/:user_id/applications` - Get employer applications
- `PUT /api/users/:app_id/status` - Update application status

## Future Enhancements

- Real-time notifications
- Advanced search filters (salary range, experience level, etc.)
- Email notifications
- File upload for resumes
- Application tracking system
- Messaging between employer and jobseeker
- Admin panel
- Payment integration for premium features
- Review and rating system
- Advanced analytics dashboard

## Environment Variables

Create a `.env` file with:
```
PORT=5000
NODE_ENV=development
JWT_SECRET=your_jwt_secret_key_change_this
```

## Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: Node.js, Express.js
- **Database**: SQLite3
- **Authentication**: JWT, bcryptjs

## Usage

### For Job Seekers
1. Register an account as a "Job Seeker"
2. Complete your profile with bio, skills, and resume
3. Browse and search for jobs
4. Apply to jobs directly
5. Track application status in dashboard

### For Employers
1. Register an account as an "Employer"
2. Complete company profile
3. Post job listings
4. Review incoming applications
5. Manage candidates and update application status

## Notes

- Database is created automatically on first run (jobportal.db)
- Passwords are hashed using bcryptjs
- JWT tokens expire after 7 days
- All API responses are in JSON format

## Getting Started with Upgrades

Once you're comfortable with the base, you can:
1. Add email notification system
2. Implement file uploads for resumes
3. Create admin dashboard
4. Add advanced search features
5. Implement real-time chat between users
6. Add payment processing

Feel free to expand and customize as needed!
