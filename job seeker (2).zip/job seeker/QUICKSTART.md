# Quick Start Guide

## 1. Setup (First Time Only)

```bash
# Navigate to the project folder
cd "job seeker"

# Install all dependencies
npm install
```

## 2. Start the Server

```bash
# Production mode
npm start

# OR Development mode (auto-restarts on changes)
npm run dev
```

You should see:
```
Connected to SQLite database
Database schema initialized
Server is running on http://localhost:5000
```

## 3. Open in Browser

Visit: **http://localhost:5000**

## 4. Test the Features

### As a Job Seeker:
1. Click "Sign Up"
2. Fill in: Name, Email, Password, Select "Job Seeker"
3. Click "Sign Up"
4. You'll be redirected to Dashboard
5. Go to "Browse Jobs" to see available jobs
6. Click "Apply Now" to apply

### As an Employer:
1. Click "Sign Up"
2. Fill in: Name, Email, Password, Select "Employer"
3. Click "Sign Up"
4. Go to Dashboard → Job Listings
5. Click "Post New Job" to create a listing (feature under development)

## 5. Sample Test Data

To add sample jobs to the database for testing, you can use the `seed-data.js` file (to be created) or make an API call:

### Using cURL to add a job:
```bash
curl -X POST http://localhost:5000/api/jobs \
  -H "Content-Type: application/json" \
  -d '{
    "employer_id": 1,
    "title": "Senior JavaScript Developer",
    "description": "We are looking for an experienced JavaScript developer...",
    "job_type": "Full-time",
    "location": "San Francisco, CA",
    "salary_min": 100000,
    "salary_max": 150000,
    "qualifications": "5+ years experience with JavaScript, React",
    "responsibilities": "Build and maintain web applications"
  }'
```

## 6. Project Pages

| Page | URL | Purpose |
|------|-----|---------|
| Home | `/` | Landing page with featured jobs |
| Register | `/register` | Create new account |
| Login | `/login` | Login to account |
| Browse Jobs | `/jobs` | Search and filter jobs |
| Dashboard | `/dashboard` | Manage profile and applications |

## 7. Database

- **Location**: `jobportal.db` (created automatically)
- **Type**: SQLite3
- **Reset**: Delete `jobportal.db` to reset the database

## 8. Common Issues

### Port 5000 already in use
```bash
# Kill the process using port 5000 or change PORT in .env
```

### Database errors
- Delete `jobportal.db` file
- Restart the server

### Can't connect to http://localhost:5000
- Make sure the server is running
- Check that port 5000 is not blocked by firewall

## 9. Next Steps

After getting the base working:
1. Test user registration and login
2. Create sample job listings
3. Test job search functionality
4. Review the API routes in `src/routes/`
5. Plan your enhancements

## 10. Useful Commands

```bash
# Install new package
npm install package-name

# Check installed packages
npm list

# Stop the server
Ctrl + C

# Clear npm cache
npm cache clean --force
```

Enjoy building! 🚀
