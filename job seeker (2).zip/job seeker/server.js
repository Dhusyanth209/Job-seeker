const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
// Serve global styles
app.use('/styles', express.static(path.join(__dirname, 'styles')));

// Serve HTML files
app.set('view engine', 'html');
app.set('views', path.join(__dirname, 'views'));
app.engine('html', (filepath, options, callback) => {
  require('fs').readFile(filepath, (err, content) => {
    if (err) return callback(err);
    return callback(null, content.toString());
  });
});

// Database initialization
const { db } = require('./src/config/db');

// Routes
app.get('/', (req, res) => {
  res.render('index.html');
});

app.get('/login', (req, res) => {
  res.render('login.html');
});

app.get('/register', (req, res) => {
  res.render('register.html');
});

app.get('/dashboard', (req, res) => {
  res.render('dashboard.html');
});

app.get('/company-dashboard', (req, res) => {
  res.render('company_dashboard.html');
});

app.get('/jobs', (req, res) => {
  res.render('jobs.html');
});

app.get('/jobs/:id', (req, res) => {
  res.render('view_job.html');
});

// API Routes - Auth
const authRoutes = require('./src/routes/auth');
app.use('/api/auth', authRoutes);

// API Routes - Jobs
const jobRoutes = require('./src/routes/jobs');
app.use('/api/jobs', jobRoutes);

// API Routes - Users
const userRoutes = require('./src/routes/users');
app.use('/api/users', userRoutes);

// API Routes - Tools (Resume Gen)
const toolRoutes = require('./src/routes/tools');
app.use('/api/tools', toolRoutes);

// API Routes - Company
const companyRoutes = require('./src/routes/company');
app.use('/api/company', companyRoutes);

app.get('/admin-dashboard', (req, res) => {
  res.render('admin_dashboard.html');
});

// API Routes - Admin
const adminRoutes = require('./src/routes/admin');
app.use('/api/admin', adminRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

module.exports = { db };
