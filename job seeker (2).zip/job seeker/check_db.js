const { db } = require('./src/config/db');

db.all("SELECT * FROM job_listings", [], (err, rows) => {
    if (err) {
        console.error("Error:", err);
    } else {
        console.log(`Found ${rows.length} jobs.`);
        console.log(rows);
    }
});
