const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../config/db');

// --- OTP Store (In-memory for Demo) ---
const otpStore = {}; // { "email_or_phone": "1234" }

// 1. Send OTP
router.post('/send-otp', (req, res) => {
  const { target, type } = req.body;
  if (!target) return res.status(400).json({ error: "Target is required" });

  // Generate 4-digit OTP
  const otp = Math.floor(1000 + Math.random() * 9000).toString();
  otpStore[target] = otp;

  // Simulate sending email/SMS
  console.log(`[OTP-SIM] Sending OTP ${otp} to ${target} (${type})`);

  // Return OTP in response for Demo purposes (so user can copy-paste)
  res.json({ success: true, message: `OTP sent to ${type}`, demo_otp: otp });
});

// 2. Verify OTP
router.post('/verify-otp', (req, res) => {
  const { target, otp } = req.body;
  if (otpStore[target] === otp) {
    delete otpStore[target]; // Burn OTP
    res.json({ success: true, message: "Verified" });
  } else {
    res.status(400).json({ error: "Invalid OTP" });
  }
});

// 3. Login with OTP (Email only as per request)
router.post('/login-otp', (req, res) => {
  const { email } = req.body;

  // Check if user exists
  db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
    if (err || !user) {
      return res.status(404).json({ error: 'User not found. Please register first.' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, user_type: user.user_type },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '7d' }
    );

    res.json({ message: 'Login successful', token, user: { id: user.id, email: user.email, user_type: user.user_type } });
  });
});

// 4. Register with OTP (Email & Phone Verified)
router.post('/register-otp', (req, res) => {
  const { email, phone, full_name, user_type } = req.body;

  // Password is now optional/random since we use OTP
  const tempPassword = bcrypt.hashSync("passwordless_" + Date.now(), 10);

  db.run(
    'INSERT INTO users (email, phone, password, full_name, user_type) VALUES (?, ?, ?, ?, ?)',
    [email, phone, tempPassword, full_name, user_type],
    function (err) {
      if (err) {
        return res.status(400).json({ error: 'Email already exists' });
      }

      const token = jwt.sign(
        { id: this.lastID, email, user_type },
        process.env.JWT_SECRET || 'secret',
        { expiresIn: '7d' }
      );

      res.status(201).json({ message: 'User registered successfully', token });
    }
  );
});

module.exports = router;
