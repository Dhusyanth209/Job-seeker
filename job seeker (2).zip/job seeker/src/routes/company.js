const express = require('express');
const router = express.Router();
const { db } = require('../config/db');

// Verify Company (Upload Docs)
router.post('/verify', (req, res) => {
    const { employer_id, document_url } = req.body;

    // In real app: Validate file type, size, upload to cloud storage
    // Here: Update DB directly
    db.run(`UPDATE employer_profiles SET is_verified = 1, verification_doc = ? WHERE user_id = ?`,
        [document_url, employer_id],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: "Documents submitted. Verification status: PENDING APPROVAL (Auto-approved for demo)" });
        }
    );
});

// Close Vacancy
router.post('/jobs/:id/close', (req, res) => {
    const jobId = req.params.id;
    db.run(`UPDATE job_listings SET status = 'closed' WHERE id = ?`, [jobId], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Vacancy closed successfully." });
    });
});

module.exports = router;
