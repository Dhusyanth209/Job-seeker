const express = require('express');
const router = express.Router();
const { db } = require('../config/db');

// Get Pending Verifications
router.get('/pending-verifications', (req, res) => {
    // Verified = 0 AND has a document uploaded (simulated check: verification_doc IS NOT NULL)
    // Actually our DB init set default 0. Let's just return all 0s for demo.
    const sql = `SELECT * FROM employer_profiles WHERE is_verified = 0 OR is_verified IS NULL`;

    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// Approve Company
router.post('/approve-company', (req, res) => {
    const { employer_id } = req.body;
    db.run(`UPDATE employer_profiles SET is_verified = 1 WHERE user_id = ?`, [employer_id], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Company Approved" });
    });
});

module.exports = router;
