const express = require('express');
const router = express.Router();
const { db } = require('../config/db');

// Get all jobs
router.get('/', (req, res) => {
  const { location, job_type, keyword } = req.query;
  let query = 'SELECT * FROM job_listings WHERE status = "active"';
  let params = [];

  if (location) {
    query += ' AND location LIKE ?';
    params.push(`%${location}%`);
  }

  if (job_type) {
    query += ' AND job_type = ?';
    params.push(job_type);
  }

  if (keyword) {
    query += ' AND (title LIKE ? OR description LIKE ?)';
    params.push(`%${keyword}%`, `%${keyword}%`);
  }

  query += ' ORDER BY posted_date DESC';
  console.log("Executing query:", query, params);

  db.all(query, params, (err, jobs) => {
    console.log("Query result count:", jobs ? jobs.length : "null");
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(jobs);
  });
});

// Get single job
router.get('/:id', (req, res) => {
  db.get('SELECT * FROM job_listings WHERE id = ?', [req.params.id], (err, job) => {
    if (err || !job) {
      return res.status(404).json({ error: 'Job not found' });
    }
    res.json(job);
  });
});

// Create job (employer only)
router.post('/', (req, res) => {
  const { employer_id, title, description, job_type, location, salary_min, salary_max, qualifications, responsibilities, deadline } = req.body;

  if (!employer_id || !title || !description) {
    return res.status(400).json({ error: 'Required fields missing' });
  }

  db.run(
    'INSERT INTO job_listings (employer_id, title, description, job_type, location, salary_min, salary_max, qualifications, responsibilities, deadline) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [employer_id, title, description, job_type, location, salary_min, salary_max, qualifications, responsibilities, deadline],
    function (err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to create job' });
      }
      res.status(201).json({ message: 'Job created successfully', id: this.lastID });
    }
  );
});

// Update job
router.put('/:id', (req, res) => {
  const { title, description, job_type, location, salary_min, salary_max, qualifications, responsibilities, deadline, status } = req.body;

  db.run(
    'UPDATE job_listings SET title = ?, description = ?, job_type = ?, location = ?, salary_min = ?, salary_max = ?, qualifications = ?, responsibilities = ?, deadline = ?, status = ? WHERE id = ?',
    [title, description, job_type, location, salary_min, salary_max, qualifications, responsibilities, deadline, status, req.params.id],
    function (err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to update job' });
      }
      res.json({ message: 'Job updated successfully' });
    }
  );
});

// Delete job
router.delete('/:id', (req, res) => {
  db.run('DELETE FROM job_listings WHERE id = ?', [req.params.id], function (err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to delete job' });
    }
    res.json({ message: 'Job deleted successfully' });
  });
});

// Get job recommendations (Simulated AI)
router.get('/recommendations', (req, res) => {
  // In a real app, this would use ML/AI. Here we simulate "smart" matching.
  // We'll return a mix of recent jobs with a "match score".
  const sql = `SELECT * FROM job_listings ORDER BY posted_date DESC LIMIT 5`;
  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    // Add simulated match metadata
    const recommendedJobs = rows.map(job => ({
      ...job,
      matchScore: Math.floor(Math.random() * (98 - 70) + 70), // Random score between 70-98
      matchReason: "Matches your skills in Web Development" // Static reason for demo
    }));
    res.json({
      message: "Personalized recommendations generated",
      data: recommendedJobs
    });
  });
});

module.exports = router;
