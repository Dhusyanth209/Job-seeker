const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Database initialization
const dbPath = path.resolve(__dirname, '../../jobportal.db');
console.log("DB PATH:", dbPath);
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
    initializeDatabase();
  }
});

// Initialize database schema
function initializeDatabase() {
  db.serialize(() => {
    // Users table
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        phone TEXT,
        password TEXT,
        full_name TEXT NOT NULL,
        user_type TEXT NOT NULL,
        profile_pic TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Job Seeker Profiles
    db.run(`
      CREATE TABLE IF NOT EXISTS jobseeker_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        bio TEXT,
        phone TEXT,
        location TEXT,
        resume_url TEXT,
        skills TEXT,
        experience TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
      )
    `);

    // Employer Profiles
    db.run(`
      CREATE TABLE IF NOT EXISTS employer_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        company_name TEXT NOT NULL,
        company_size TEXT,
        industry TEXT,
        website TEXT,
        phone TEXT,
        location TEXT,
        description TEXT,
        is_verified INTEGER DEFAULT 0,
        verification_doc TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
      )
    `);

    // Job Listings
    db.run(`
      CREATE TABLE IF NOT EXISTS job_listings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employer_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        job_type TEXT,
        location TEXT,
        salary_min REAL,
        salary_max REAL,
        qualifications TEXT,
        responsibilities TEXT,
        posted_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        deadline DATETIME,
        status TEXT DEFAULT 'active',
        FOREIGN KEY(employer_id) REFERENCES users(id)
      )
    `);

    // Job Applications
    db.run(`
      CREATE TABLE IF NOT EXISTS job_applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER NOT NULL,
        jobseeker_id INTEGER NOT NULL,
        application_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'pending',
        cover_letter TEXT,
        FOREIGN KEY(job_id) REFERENCES job_listings(id),
        FOREIGN KEY(jobseeker_id) REFERENCES users(id)
      )
    `);

    console.log('Database schema initialized');
  });
}

module.exports = { db };
